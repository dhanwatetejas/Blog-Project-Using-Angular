import { Component } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.css',
})
export class RegistrationComponent {
  authError:string='';
  ifShowLogin: boolean = true;
  isSellerLoggedIn = new BehaviorSubject<boolean>(false);

  openRegistration() {
    this.ifShowLogin = true;
  }
  openLogin() {
    this.ifShowLogin = false;
  }
  constructor(private registerUser: UserService,private router:Router) {}
  registrationForm = new FormGroup({
    firstName: new FormControl('',Validators.required),
    lastName: new FormControl('',Validators.required),
    email: new FormControl('',Validators.required),
    password: new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(10),Validators.pattern('[0-9A-Za-z]')]),
    confirmPassword: new FormControl('',Validators.required),
  });

  get PWD():FormControl{
    return this.registrationForm.get('password') as FormControl;
  }
  get CFPWD():FormControl{
    return this.registrationForm.get('confirmPassword') as FormControl;
  }
  submitRegistration() {
    // console.log(this.registrationForm.value);
    if(this.PWD.value == this.CFPWD.value){
    this.registerUser.userRegistration(this.registrationForm.value).subscribe((result)=>{
      console.log(result);
      this.ifShowLogin = false;
      

    })
  }else{console.log('password not same');

  }
    
  }
  loginForm = new FormGroup({
    email: new FormControl('',Validators.required),
    password: new FormControl('',Validators.required),
  });
  submitLogin() {
    
    // console.log(this.loginForm.value);
    if(this.loginForm.value.email && this.loginForm.value.password){
      this.authError =''; 
      console.log(this.loginForm.value);
      this.registerUser.userLogin(this.loginForm.value);
      
      this.registerUser.isLoginError.subscribe((isError)=>{
        if(isError){
          this.authError='Wrong Credentials';
        }
        
      })
  }else{
    this.authError ='Both fields required';
  }
}
}
