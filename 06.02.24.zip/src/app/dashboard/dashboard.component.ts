import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class DashboardComponent {
  constructor(private route: Router, private service: UserService) {}
  userName: string = '';
  userEmail: string = '';
  blogListObject:any[]=[]
  xyz:any []=[];
  editId:any;

  ngOnInit(): void {
    if (localStorage.getItem('user')) {
      let userStore = localStorage.getItem('user');
      let userData = userStore && JSON.parse(userStore)[0];
      this.userName = `Hello ${userData.firstName} ${userData.lastName}`;
      this.userEmail = userData.email;
    }

    this.service.blogList().subscribe((result) => {
      // console.log("result",typeof(result));
      let abc=   Object.values(result)
      // let abc=[]
// abc.push(result)
// console.log("abc",abc);
abc.forEach(ele=> {
  if(ele.userEmail==this.userEmail)
  {
    // console.log("34",ele);
    
    this.blogListObject.push(ele);

  }
  
});

  // this.xyz.push(ele)

// console.log("xyz",this.xyz);


    //  this.blogListObject = result;
      // console.log('This is blog list',typeof(this.blogListObject));

      // console.log(this.blogListObject);
    });
  }
  gotoAddBlog() {
    this.route.navigate(['dashboardNavbar/addBlog']);
  }
  blogDisplay(data:any){
    // console.log("this is object id",data);
    this.service.setData(data);
    this.route.navigate(['dashboardNavbar/blogDisplay'])
    
    // console.log("id data is",data);/
    
  }
  // deleteBlog(id:number){
  //   console.log("test id is",id);
  editBlog(data:any){
    this.editId=data;
    console.log("edit id =",this.editId);
    
    
    this.route.navigate(['editblog',data.id]);
    
    
        // this.service.setData(data);
        // this.editForm.controls['desc'].setValue(this.editId.description);
        // this.editForm.patchValue(this.editId.description  )
       

      

   

  }

  // }
}
