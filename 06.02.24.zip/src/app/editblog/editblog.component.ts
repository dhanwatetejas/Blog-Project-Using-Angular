import { Component } from "@angular/core";
import { UserService } from "../services/user.service";
import { FormGroup } from "@angular/forms";
import { FormControl } from "@angular/forms";
import { Router } from "@angular/router";
import { ActivatedRoute } from "@angular/router";
@Component({
  selector: "app-editblog",
  templateUrl: "./editblog.component.html",
  styleUrl: "./editblog.component.css",
})
export class EditblogComponent {
  constructor(
    private service: UserService,
    private route: Router,
    private actroute: ActivatedRoute
  ) {}

  blogForm = new FormGroup({
    title: new FormControl(""),
    link: new FormControl(""),
    description: new FormControl(""),
    file: new FormControl(""),
    userEmail: new FormControl(),
    status:new FormControl('')
  });
  fetchData: any;
  id: any;
  userEmail: string = "";
  ngOnInit(): void {
    // if (localStorage.getItem('user')) {
    //   let userStore = localStorage.getItem('user');
    //   let userData = userStore && JSON.parse(userStore)[0];
    //   // this.userName=`Hello ${userData.firstName} ${userData.lastName}`
    //   this.userEmail = userData.email;
    // }
    this.actroute.paramMap.subscribe((param) => {
      console.log("Param is =",param);
      
      this.id = param.get("id");
      console.log("id =", this.id);
      if (this.id) {
        this.service.getById(this.id).subscribe((result) => {
          console.log("This is blog data=", result);
          this.fetchData = result;
          this.blogForm.patchValue(this.fetchData);
        });
      }
    });
  }

  updateData() {
    this.service.updateBlog(this.id,this.blogForm.value).subscribe((res)=>{
      console.log("Result is =",res);
      this.route.navigate(['dashboardNavbar/dashboard'])
      
    })
    // console.log("updated data is",this.blogForm.value);
    
  }
}
