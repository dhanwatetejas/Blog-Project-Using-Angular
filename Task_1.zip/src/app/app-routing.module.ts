import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserGuardGuard } from './user-guard.guard';
import { LoginComponent } from './login/login.component';
import { AddBlogComponent } from './add-blog/add-blog.component';
import { DashboardNavbarComponent } from './dashboard-navbar/dashboard-navbar.component';
import { BlogDisplayComponent } from './blog-display/blog-display.component';

const routes: Routes = [
  { path: '', component: RegistrationComponent },

  {
    path: 'dashboardNavbar',
    component: DashboardNavbarComponent,
    canActivate: [UserGuardGuard],
    children: [
      {
        path: 'dashboard',
        component: DashboardComponent,
      },
      {
        path: 'addBlog',
        component: AddBlogComponent,
      },
      {
        path: 'blogDisplay',
        component: BlogDisplayComponent,
      },
    ],
  },

  {
    path: 'login',
    component: LoginComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
