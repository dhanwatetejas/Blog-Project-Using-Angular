import { Component } from '@angular/core';
import { UserService } from '../services/user.service';
// import { Observable } from 'rxjs';

@Component({
  selector: 'app-blog-display',
  templateUrl: './blog-display.component.html',
  styleUrl: './blog-display.component.css'
})
export class BlogDisplayComponent {
constructor(private service:UserService){}
blogData:any;
displayArray:[]=[];
image = document.getElementById('blogImage');

ngOnInit():void{
  this.blogData=this.service.getData();

  //  this.displayArray.push(this.blogData);
  console.log("BlogData=",this.blogData);
  // this.displayArray=values;
  let imagePath=this.blogData.file
  this.image?.setAttribute('src',imagePath)
  
}
}
