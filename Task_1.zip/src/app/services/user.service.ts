import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';

// import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  completeBlogData={};
  constructor(private http:HttpClient,private router:Router) { }
  isLoginError = new EventEmitter <boolean>(false);
  userRegistration(data:any){
    return this.http.post('http://localhost:3000/user',data)
    // console.log("service called");
    

  }
  addBlog(data:any){
    return this.http.post('http://localhost:3000/blog',data)
    // console.log("service called");
    

  }
  blogList(){
    return this.http.get('http://localhost:3000/blog');
  }
// checking if email is unique
  chechMail(){
    return this.http.get('http://localhost:3000/user')

  }

  userLogin(data:any){
    console.log(data);
    console.log('user login called');
    
    this.http.get(`http://localhost:3000/user?email=${data.email}&password=${data.password}`,
    {observe:'response'}).subscribe((result:any)=>{
      console.log("this is login result",result);
      if(result && result.body && result.body.length){
        console.log('User Logged In ');
        localStorage.setItem('user',JSON.stringify(result.body))
        this.router.navigate(['dashboardNavbar/dashboard'])
        
      }
      else{ console.log('Failed Log In');
      this.isLoginError.emit(true);
    }
      
    })
    
       
  }
  setData(data:any){
    this.completeBlogData=data;
    // console.log("set data called =",this.completeBlogData);
    
  }
  getData(){
    return this.completeBlogData;
  }

}
