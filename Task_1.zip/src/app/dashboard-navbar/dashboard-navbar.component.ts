import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-dashboard-navbar',
  templateUrl: './dashboard-navbar.component.html',
  styleUrl: './dashboard-navbar.component.css'
})
export class DashboardNavbarComponent {
  constructor(private route:Router){}
  
  userName:string='';
  ngOnInit():void{
    if(localStorage.getItem('user')){
      let userStore=localStorage.getItem('user');
      let userData =userStore && JSON.parse(userStore)[0];
      this.userName=`Hello ${userData.firstName} ${userData.lastName}`
    }

  }
  logout(){
    localStorage.removeItem('user');
    this.route.navigate(['']);
  }
}
