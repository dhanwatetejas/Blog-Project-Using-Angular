import { Component } from '@angular/core';
import { UserService } from '../services/user.service';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
@Component({
  selector: 'app-add-blog',
  templateUrl: './add-blog.component.html',
  styleUrl: './add-blog.component.css'
})
export class AddBlogComponent {
  userEmail:string='';
  ngOnInit():void{
    if(localStorage.getItem('user')){
      let userStore=localStorage.getItem('user');
      let userData =userStore && JSON.parse(userStore)[0];
      // this.userName=`Hello ${userData.firstName} ${userData.lastName}`
      this.userEmail=userData.email;
    }
  }
  
  
  constructor(private service:UserService){}
  blogForm=new FormGroup({
    title:new FormControl(''),
    link:new FormControl(''),
    description:new FormControl(''),
    file:new FormControl(''),
    userEmail: new FormControl ()
  })

  
  
  
  addBlogData(){
     
  let formData ={...this.blogForm.value};
  console.log( formData,"this.userEmail",this.userEmail);
  
   formData.userEmail = this.userEmail;
    this.service.addBlog(formData).subscribe((result)=>{
      console.log(result);
      
    })
  }
}

// submitRegistration() {
//   // console.log(this.registrationForm.value);
//   this.registerUser.userRegistration(this.registrationForm.value).subscribe((result)=>{
//     console.log(result);
    

//   })