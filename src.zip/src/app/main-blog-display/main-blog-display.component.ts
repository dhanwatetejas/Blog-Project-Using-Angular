import { Component } from '@angular/core';
import { UserService } from '../services/user.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-main-blog-display',
  templateUrl: './main-blog-display.component.html',
  styleUrl: './main-blog-display.component.css'
})
export class MainBlogDisplayComponent {
  id:any;
  constructor(private service:UserService,private actroute:ActivatedRoute){}
  
  ngOnInit(){
    this.service.blogList().subscribe((res)=>{
console.log(res);

    })
    this.actroute.paramMap.subscribe((param)=>{
      
      this.id=param.get('id');
      console.log("param id is =",this.id);
      
    })
    
  }
  


}
