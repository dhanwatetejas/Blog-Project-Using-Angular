import { Component } from '@angular/core';
import { UserService } from '../services/user.service';
import { FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-landingpage',
  templateUrl: './landingpage.component.html',
  styleUrl: './landingpage.component.css'
})
export class LandingpageComponent {
  constructor(private service:UserService,private route:Router){}
  blogData:any;
  editId:any;
  displayForm:boolean=true;
  selectedForm:[]=[];
  
  ngOnInit(){
    
    this.service.blogList().subscribe((result)=>{
      // console.log("this is result",result);
      this.blogData=result;
      // console.log("this is blogdata",this.blogData[1]);
      this.blogData.forEach((ele:any)=>{
        // console.log("this is ele",ele);
        


      })
      
    })
  }
  editForm = new FormGroup({
    desc:new FormControl(''),
  })
  editBlog(data:any){
    this.editId=data;
    console.log("edit id =",this.editId);
    
    // this.service.setData(data);
    this.route.navigate(['editblog',data.id]);
    
    
        
        // this.editForm.controls['desc'].setValue(this.editId.description);
        // this.editForm.patchValue(this.editId.description  )
       

      

   

  }

}
