import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  constructor(private route:Router,private service:UserService){}
  userName:string='';
  userEmail:string='';
 
  ngOnInit():void{
    if(localStorage.getItem('user')){
      let userStore=localStorage.getItem('user');
      let userData =userStore && JSON.parse(userStore)[0];
      this.userName=`Hello ${userData.firstName} ${userData.lastName}`;
      this.userEmail=userData.email;
      
    }
  //   this.service.blogList().subscribe((result)=>{
  //     console.log(result);
  //     // this.blogList=result;
      
  //   })
   }
  gotoAddBlog(){
    this.route.navigate(['dashboardNavbar/addBlog'])
  }
}
