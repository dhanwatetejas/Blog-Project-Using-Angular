import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { RegistrationComponent } from "./registration/registration.component";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { UserGuardGuard } from "./user-guard.guard";
import { LoginComponent } from "./login/login.component";
import { AddBlogComponent } from "./add-blog/add-blog.component";
import { DashboardNavbarComponent } from "./dashboard-navbar/dashboard-navbar.component";
import { BlogDisplayComponent } from "./blog-display/blog-display.component";
import { LandingpageComponent } from "./landingpage/landingpage.component";
import { EditPageComponent } from "./edit-page/edit-page.component";
import { EditblogComponent } from "./editblog/editblog.component";
import { DisplayListingComponent } from "./display-listing/display-listing.component";
import { MainBlogDisplayComponent } from "./main-blog-display/main-blog-display.component";

const routes: Routes = [
  { path: 'editblog/:id', component: EditblogComponent },
  {path:'mainlisting',component:DisplayListingComponent},
  {path:'mainblogdisplay/:id',component:MainBlogDisplayComponent},
  // { path: 'edit/:id', component: EditPageComponent },
  { path: "landingpage", component: LandingpageComponent },
  { path: "", component: RegistrationComponent },
  {
    path: "dashboardNavbar",
    component: DashboardNavbarComponent,
    // canActivate: [UserGuardGuard],
    children: [
      {
        path: "dashboard",
        component: DashboardComponent,
      },
      {
        path: "addBlog",
        component: AddBlogComponent,
      },
      {
        path: "blogDisplay",
        component: BlogDisplayComponent,
      },
 

    ],
  },

  {
    path: "login",
    component: LoginComponent,
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
