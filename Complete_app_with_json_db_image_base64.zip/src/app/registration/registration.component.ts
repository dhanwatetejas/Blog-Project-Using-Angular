import { Component } from "@angular/core";
import { FormGroup, Validators } from "@angular/forms";
import { FormControl } from "@angular/forms";
import { UserService } from "../services/user.service";
import { Router } from "@angular/router";
import { BehaviorSubject } from "rxjs";
import { IfStmt } from "@angular/compiler";

@Component({
  selector: "app-registration",
  templateUrl: "./registration.component.html",
  styleUrl: "./registration.component.css",
})
export class RegistrationComponent {
  authError: string = "";
  ifShowLogin: boolean = true;
  isSellerLoggedIn = new BehaviorSubject<boolean>(false);
  emailData: any;
  userExist: boolean=false;
  samePassword:string="";
  existingUserWarning:string='';

  openRegistration() {
    this.ifShowLogin = true;
  }
  openLogin() {
    this.ifShowLogin = false;
  }
  constructor(private registerUser: UserService, private router: Router) {}
  registrationForm = new FormGroup({
    firstName: new FormControl("", Validators.required),
    lastName: new FormControl("", Validators.required),
    email: new FormControl("", Validators.required),
    password: new FormControl("", [
      Validators.required,
      
    ]),
    confirmPassword: new FormControl("", Validators.required),
  });

  get mail(): FormControl {
    return this.registrationForm.get("email") as FormControl;
  }
  get PWD(): FormControl {
    return this.registrationForm.get("password") as FormControl;
  }
  get CFPWD(): FormControl {
    return this.registrationForm.get("confirmPassword") as FormControl;
  }
  submitRegistration() {
    // console.log(this.registrationForm.value);
    this.registerUser.chechMail().subscribe((result) => {
      // console.log("this is result value",result);
      let abc = Object.values(result);

      abc.forEach((ele) => {
        // consol e.log("this is ele",ele);
        if (ele.email == this.mail.value) {
          this.userExist = true;
          // this.existingUserWarning=this.userExist;

        }
        
      });
      
    });

    // console.log("This is mail =",this.mail.value);

    if (
      this.PWD.value == this.CFPWD.value &&
      this.userExist !== true
    ) {
      this.registerUser
        .userRegistration(this.registrationForm.value)
        .subscribe((result) => {
          // this.samePassword="Password Match"
          // console.log(result);
          // this.ifShowLogin = false;
          alert("User Registered");
          this.ifShowLogin = false;
          

        });
    } else {
      console.log("password not same");
      
    }
    if(this.PWD.value == this.CFPWD.value){
      this.samePassword=""

    }else {this.samePassword="Password Not Match";}
  }
  loginForm = new FormGroup({
    email: new FormControl("", Validators.required),
    password: new FormControl("", Validators.required),
  });
  submitLogin() {
    // console.log(this.loginForm.value);
    if (this.loginForm.value.email && this.loginForm.value.password) {
      this.authError = "";
      console.log(this.loginForm.value);
      this.registerUser.userLogin(this.loginForm.value);

      this.registerUser.isLoginError.subscribe((isError) => {
        if (isError) {
          this.authError = "Wrong Credentials";
        }
      });
    } else {
      this.authError = "Both fields required";
    }
  }
}
