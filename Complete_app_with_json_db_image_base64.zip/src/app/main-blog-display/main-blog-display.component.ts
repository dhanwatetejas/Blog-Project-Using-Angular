import { Component } from '@angular/core';
import { UserService } from '../services/user.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-main-blog-display',
  templateUrl: './main-blog-display.component.html',
  styleUrl: './main-blog-display.component.css'
})
export class MainBlogDisplayComponent {
  id:any;
  blogData:any;
  constructor(private service:UserService,private actroute:ActivatedRoute){}
  
  ngOnInit(){
    this.actroute.paramMap.subscribe((param)=>{
      
      this.id=param.get('id');
      console.log("param id is =",this.id);
      
    })
    this.service.blogList().subscribe((res)=>{
let abc = Object.values(res)
console.log("this is abc",abc);
abc.forEach((ele)=>{
  if(ele.id==this.id){
    this.blogData=ele;

  }


})

    })
    
    
    
  }
  


}
