import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainBlogDisplayComponent } from './main-blog-display.component';

describe('MainBlogDisplayComponent', () => {
  let component: MainBlogDisplayComponent;
  let fixture: ComponentFixture<MainBlogDisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainBlogDisplayComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MainBlogDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
