import { Component } from "@angular/core";
import { UserService } from "../services/user.service";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: "app-display-listing",
  templateUrl: "./display-listing.component.html",
  styleUrl: "./display-listing.component.css",
})
export class DisplayListingComponent {
  name: string = "";
  constructor(private service: UserService, private route: Router) {}
  blogId: any;
  blogData: any[] = [];
  filteredList: any;
  newArray: any[] = [];
  itemsperpage = 3;
  // POSTS:any;
  page: number = 1;
  displayBlog_from_home(data: any) {
    this.blogId = data;
    this.route.navigate(["mainblogdisplay", this.blogId.id]);
  }
  display_Auhor_Name(data:any){
    


  }
  ngOnInit() {
    this.service.blogList().subscribe((result) => {
      console.log("result=", typeof result);
      console.log(result);
      let abc = Object.values(result);
      abc.forEach((ele) => {
        
        this.blogData.push(ele);
      });
      console.log("type of blogData", typeof this.blogData);
      this.newArray = this.blogData.filter((ele) => {
        return ele.status == "pub";
      });
      abc.forEach((element)=>{


      })
      

      // console.log("this is result",result);
      // this.blogData=result;
      // console.log("blogData",typeof(this.blogData));
      // console.log(this.blogData);

      // console.log("this is blogdata",this.blogData[1]);
      // this.blogData.forEach((ele:any)=>{
      // console.log("this is ele",ele);
      // // console.log(ele.status=='pub');
      // if(ele.status=='pub'){
      //   console.log(ele);

      // }
    });

    // })
  }
}
