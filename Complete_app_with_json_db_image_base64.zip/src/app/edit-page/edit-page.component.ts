import { Component } from '@angular/core';
import { UserService } from '../services/user.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-edit-page',
  templateUrl: './edit-page.component.html',
  styleUrl: './edit-page.component.css'
})
export class EditPageComponent {
  constructor(private service:UserService,private actRoute:ActivatedRoute){}
blogData:any;
id:any;

  ngOnInit(){
    // this.blogData=this.service.getData();

    //  this.displayArray.push(this.blogData);
    // console.log("BlogData=",this.blogData);
    this.actRoute.paramMap.subscribe((params)=>{
      this.blogData=params.get('id');
      console.log("This is id = ",this.blogData);
      

    })

  }

}
