import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.css',
})
export class RegistrationComponent {
  authError:string='';
  ifShowLogin: boolean = true;
  isSellerLoggedIn = new BehaviorSubject<boolean>(false);

  openRegistration() {
    this.ifShowLogin = true;
  }
  openLogin() {
    this.ifShowLogin = false;
  }
  constructor(private registerUser: UserService,private router:Router) {}
  registrationForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    email: new FormControl(''),
    password: new FormControl(''),
    confirmPassword: new FormControl(''),
  });
  submitRegistration() {
    // console.log(this.registrationForm.value);
    this.registerUser.userRegistration(this.registrationForm.value).subscribe((result)=>{
      console.log(result);
      

    })
    this.ifShowLogin = false;
  }
  loginForm = new FormGroup({
    email: new FormControl(''),
    password: new FormControl(''),
  });
  submitLogin() {
    
    // console.log(this.loginForm.value);
    if(this.loginForm.value.email && this.loginForm.value.password){
      this.authError =''; 
      console.log(this.loginForm.value);
      this.registerUser.userLogin(this.loginForm.value);
      
      this.registerUser.isLoginError.subscribe((isError)=>{
        if(isError){
          this.authError='Wrong Credentials';
        }
        
      })
  }else{
    this.authError ='Both fields required';
  }
}
}
