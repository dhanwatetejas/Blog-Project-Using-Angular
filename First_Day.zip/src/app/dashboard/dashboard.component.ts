import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  constructor(private route:Router){}
  userName:string='';
  ngOnInit():void{
    if(localStorage.getItem('user')){
      let userStore=localStorage.getItem('user');
      let userData =userStore && JSON.parse(userStore)[0];
      this.userName=`Hello ${userData.firstName} ${userData.lastName}`
    }
  }
  logout(){
    localStorage.removeItem('user');
    this.route.navigate(['']);
  }
}
