import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserGuardGuard } from './user-guard.guard';
import { LoginComponent } from './login/login.component';
import { AddBlogComponent } from './add-blog/add-blog.component';

const routes: Routes = [
  {path:'',
   component:RegistrationComponent    
},
  
  {
    path:'dashboard',
    component:DashboardComponent,
    canActivate:[UserGuardGuard]
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'addBlog',
    component:AddBlogComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
